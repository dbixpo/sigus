"""
Importador de demanda (solicitação de procedimento/serviço) no SISWEB.

Lê uma planilha ODS na pasta configurada, cria solicitações com N procedimentos
e envia cada item para a fila de espera, replicando o fluxo do navegador.

Planilha (1ª linha = cabeçalho; ordem das colunas):
  1 — prontuário
  2 — data da solicitação e do envio à fila (dd/mm/yyyy); hora da solicitação fixa 00:00:00
  3 — unidade de saúde (texto auxiliar; ignorada pelo script)
  4 — código da unidade solicitante (codunidade)
  5 — procedimentos / descrição (auxiliar; ignorada — use a col. 6 para códigos)
  6 — cód. procedimentos SIGTAP, separados por vírgula
  7 — resultado (preenchido pelo script: OK / mensagem de erro)

O script não percorre o DataFrame inteiro (ex.: export do Google Sheets com milhares de
linhas vazias): só considera um bloco contíguo a partir do primeiro prontuário numérico
válido e para na primeira linha em que o prontuário estiver vazio, nulo ou zero.

Após o login, o script abre `/desktop` e extrai o JSON da sessão: o `id` da conta
(codoperadorlogin no POST) e o `seg_perfil_id` do perfil ativo — não precisa configurar.

Justificativa na solicitação e observação na fila usam o texto fixo
JUSTIFICATIVA_OBSERVACAO_FIXA (abaixo na configuração).

Processa todos os arquivos *.ods da pasta (exceto os que já começam com "OK ").
Ao terminar sem falhas em nenhuma linha daquele arquivo, renomeia-o para prefixo "OK ".

Se a solicitação for gravada mas nenhum procedimento for enviado à fila, o script tenta
excluir a solicitação (config. TENTAR_EXCLUIR_SOLICITACAO_SE_FILA_FALHAR_TUDO). Se a fila
for parcialmente enviada, não há exclusão automática.

Ambiente: por padrão homologação (sisweb-tst), como wsTrocaServico.
Para produção, altere URL_BASE e o domínio do usuário (ou use URL_PRODUCAO).

Requer: pip install requests beautifulsoup4 pandas odfpy urllib3
"""

from __future__ import annotations

import json
import re
import time
import urllib3
from datetime import datetime
from html import unescape
from pathlib import Path
from typing import Any
from urllib.parse import urlencode

import pandas as pd
import requests
from bs4 import BeautifulSoup

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# ═══════════════════════════════════════════════════════════════════════════════
# CONFIGURAÇÃO
# ═══════════════════════════════════════════════════════════════════════════════
USUARIO_SIS = ""
SENHA_SIS = ""

# Homologação (mesmo host que wsTrocaServico). Alternativa capturada no navegador:
# https://sorocaba-sp-tst.vivver.com — use se o certificado/DNS do tst público falhar.
URL_BASE = "https://sisweb-tst.sorocaba.sp.gov.br"

# Pasta com uma ou mais planilhas .ods (todas as que não começarem com "OK ")
PASTA_PLANILHAS = r"C:\Users\hardr\Desktop\solicitaRX"
# Se preenchido, processa só este arquivo (modo arquivo único)
CAMINHO_PLANILHA_EXATO: str = ""

NOME_ABA: str | int | None = None  # None = primeira aba

VERIFY_SSL = False

# Contexto da solicitação (exemplo RAIOX do ambiente de teste — ajuste por unidade/perfil)
SERVICO_TIPO_ID = "37"
COD_MUNICIPIO = "3552205"
COD_ESPECIALIDADE = "225125"  # CBO / código especialidade
# Profissional solicitante: "0" evita associar outro profissional ao formulário
COD_PROFISSIONAL = "0"
URGENCIA = "N"
QUANTIDADE_SOLICITADA = "1"

# Fila de espera (valores do exemplo capturado; ajuste conforme política local)
MOTIVO_PRIORIZACAO_ID = "124"
RAM_SERVICO_FILA_NIVEL_PRIORIDADE_ID = "9"

# Opcional: limitar quantas linhas (com prontuário válido) processar, a partir do início da faixa
LINHAS_MAX: int | None = None
DELAY_ENTRE_LINHAS = 0.35

# Hora gravada na solicitação (data_hora_inicio_solicitacao e hora_solicitacao)
HORA_SOLICITACAO_FIXA = "00:00:00"

# Se salvar a solicitação mas nenhum procedimento entrar na fila, tenta excluir a solicitação
# (evita consumir autoincrement à toa). Se algum item já foi para a fila, não exclui nada.
TENTAR_EXCLUIR_SOLICITACAO_SE_FILA_FALHAR_TUDO = True

# Texto único para solicitacao[justificativa] e observação na fila
JUSTIFICATIVA_OBSERVACAO_FIXA = "SOLICITAÇÃO TRANSCRITA (INSERIDO POR SCRIPT)"

# Índices 0-based no DataFrame (pandas). Colunas 3 e 5 da planilha existem só para preenchimento
# humano e são ignoradas; o script lê prontuário, data, cod. unidade, cód. procedimentos e resultado.
COL_PRONTUARIO = 0
COL_DATA_SOLIC = 1
# índice 2: unidade de saúde (nome) — ignorado
COL_UNIDADE = 3  # cód. unidade solicitante
# índice 4: procedimentos (texto) — ignorado
COL_PROCEDIMENTOS = 5  # cód. procedimentos (SIGTAP, vírgula)
COL_RESULTADO = 6
MIN_COLUNAS = 7

# ═══════════════════════════════════════════════════════════════════════════════


def _dominio_email_por_url(url: str) -> str:
    u = (url or "").lower()
    if "sisweb-tst" in u or "vivver" in u or "-tst" in u:
        return "@sisweb-tst.sorocaba.sp.gov.br"
    return "@sisweb.sorocaba.sp.gov.br"


def _usuario_completo(usuario: str) -> str:
    u = (usuario or "").strip()
    if "@" in u:
        return u
    dom = _dominio_email_por_url(URL_BASE)
    return f"{u}{dom}"


def _extrair_csrf(html: str) -> str:
    soup = BeautifulSoup(html, "html.parser")
    meta = soup.find("meta", {"name": "csrf-token"})
    if meta and meta.get("content"):
        return str(meta["content"]).strip()
    marker = 'meta name="csrf-token" content="'
    if marker in html:
        return html.split(marker, 1)[1].split('"', 1)[0].strip()
    raise RuntimeError("CSRF não encontrado no HTML.")


def _csrf_de_html_ou_fallback(html: str, fallback: str) -> str:
    """Meta csrf-token; se ausente (fragmento HTML), reutiliza o último CSRF válido."""
    try:
        return _extrair_csrf(html)
    except RuntimeError:
        if fallback and fallback.strip():
            return fallback.strip()
        raise


def _extrair_codoperador_e_perfil_desktop(html: str) -> tuple[str, str]:
    """
    Lê o HTML do /desktop: o atributo data-conta traz JSON com id da conta (codoperadorlogin)
    e seg_perfil_id. Aceita entidades &quot; após html.unescape.
    """
    plain = unescape(html)
    m = re.search(
        r'"id"\s*:\s*(\d+)\s*,\s*"conta"\s*:\s*"[^"]*"[^}]*?"seg_perfil_id"\s*:\s*(\d+)',
        plain,
        re.DOTALL,
    )
    if m:
        return m.group(1).strip(), m.group(2).strip()
    mseg = re.search(r'"seg_perfil_id"\s*:\s*(\d+)', plain)
    mid = re.search(r'"id"\s*:\s*(\d+)\s*,\s*"conta"', plain)
    if mseg and mid:
        return mid.group(1).strip(), mseg.group(1).strip()
    raise RuntimeError(
        "Não foi possível obter codoperadorlogin / seg_perfil_id no HTML do /desktop "
        "(procure data-conta / JSON da sessão)."
    )


def fazer_login(
    session: requests.Session,
    usuario: str,
    senha: str,
    sessao_ctx: dict[str, str] | None = None,
) -> str:
    """Login SISWEB, GET /desktop para CSRF atualizado e id do operador + seg_perfil_id."""
    session.verify = VERIFY_SSL
    session.headers.update(
        {
            "User-Agent": (
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36"
            ),
            "Accept-Language": "pt-BR,pt;q=0.9,en-US;q=0.8",
            "Connection": "keep-alive",
            "X-Requested-With": "XMLHttpRequest",
        }
    )

    res_login = session.get(f"{URL_BASE}/login", timeout=90)
    res_login.raise_for_status()
    csrf = _extrair_csrf(res_login.text)

    conta = _usuario_completo(usuario).split("@", 1)[0]

    payload = {
        "utf8": "✓",
        "page": "",
        "page_query": "",
        "conta": conta,
        "password": senha,
        "commit": "Entrar",
    }

    resp = session.post(
        f"{URL_BASE}/login/create",
        data=payload,
        headers={
            "Referer": f"{URL_BASE}/login",
            "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
            "X-CSRF-Token": csrf,
        },
        timeout=90,
    )
    resp.raise_for_status()
    if "auth_token" not in session.cookies.get_dict():
        raise RuntimeError(
            "Login não retornou auth_token nos cookies. Verifique usuário/senha e URL_BASE."
        )

    r_desk = session.get(
        f"{URL_BASE}/desktop",
        headers={
            "Referer": f"{URL_BASE}/login",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        },
        timeout=90,
    )
    r_desk.raise_for_status()
    cod_op, seg_pf = _extrair_codoperador_e_perfil_desktop(r_desk.text)
    if sessao_ctx is not None:
        sessao_ctx["codoperadorlogin"] = cod_op
        sessao_ctx["seg_perfil_id"] = seg_pf
    csrf_desktop = _csrf_de_html_ou_fallback(r_desk.text, csrf)
    print(f"Login OK (operador {cod_op}, perfil {seg_pf}).")
    return csrf_desktop


def _headers_ajax(csrf: str, referer_path: str) -> dict[str, str]:
    return {
        "Accept": "text/html, */*; q=0.01",
        "X-CSRF-Token": csrf,
        "X-Requested-With": "XMLHttpRequest",
        "Referer": f"{URL_BASE}{referer_path}",
        "Origin": URL_BASE,
    }


def buscar_paciente_id(session: requests.Session, csrf: str, numprontuario: str) -> str | None:
    params = {
        "draw": "1",
        "order[0][column]": "1",
        "order[0][dir]": "asc",
        "start": "0",
        "length": "1",
        "search[value]": "",
        "search[regex]": "false",
        "search_operator": "",
        "amb_paciente[numprontuario]": str(numprontuario),
        "amb_paciente[datcadastro]": "",
        "amb_paciente[datalteracao]": "",
        "workMode": "wmSearchResult",
        "oldWorkMode": "wmSearch",
        "_": str(int(time.time() * 1000)),
    }
    r = session.get(
        f"{URL_BASE}/amb/paciente.json",
        params=params,
        headers={
            "Accept": "application/json, text/javascript, */*; q=0.01",
            "X-CSRF-Token": csrf,
            "X-Requested-With": "XMLHttpRequest",
            "Referer": f"{URL_BASE}/amb/paciente",
        },
        timeout=90,
    )
    r.raise_for_status()
    try:
        data = r.json()
    except json.JSONDecodeError:
        return None
    rows = data.get("data") or []
    if not rows:
        return None
    rid = rows[0].get("DT_RowId")
    return str(rid).strip() if rid else None


def carregar_dados_paciente_edicao(
    session: requests.Session, csrf: str, paciente_id: str
) -> dict[str, str]:
    """Lê o formulário de edição do paciente e devolve chaves amb_paciente[...]."""
    r = session.get(
        f"{URL_BASE}/amb/paciente/{paciente_id}/edit",
        params={"workMode": "wmEdit", "oldWorkMode": "wmBrowse"},
        headers=_headers_ajax(csrf, "/amb/paciente"),
        timeout=90,
    )
    r.raise_for_status()
    soup = BeautifulSoup(r.text, "html.parser")
    form = soup.find("form")
    if not form:
        raise RuntimeError("Formulário de paciente não encontrado.")
    out: dict[str, str] = {}
    for inp in form.find_all("input"):
        name = inp.get("name")
        if not name or not str(name).startswith("amb_paciente["):
            continue
        typ = (inp.get("type") or "").lower()
        if typ in ("checkbox", "radio"):
            if inp.has_attr("checked"):
                out[name] = str(inp.get("value", "1"))
        else:
            out[name] = str(inp.get("value", "") or "")
    for ta in form.find_all("textarea"):
        name = ta.get("name")
        if name and str(name).startswith("amb_paciente["):
            out[name] = ta.text or ""
    for sel in form.find_all("select"):
        name = sel.get("name")
        if not name or not str(name).startswith("amb_paciente["):
            continue
        opt = sel.find("option", selected=True) or sel.find("option")
        out[name] = str(opt.get("value", "")) if opt else ""
    return out


def _mapear_paciente_para_solicitacao(amb: dict[str, str]) -> dict[str, str]:
    """Converte campos amb_paciente para solicitacao[...] usados no POST."""
    def g(*keys: str) -> str:
        for k in keys:
            if k in amb and str(amb[k]).strip():
                return str(amb[k]).strip()
        return ""

    nommae = g("amb_paciente[nommae]")
    datnasc = g("amb_paciente[datnascimento]")
    tel = g("amb_paciente[telcontato]", "amb_paciente[numtelefone]")
    sexo = g("amb_paciente[indsexo]", "amb_paciente[sexo]")
    if sexo:
        sexo = sexo.strip().upper()[:1] or "M"
    return {
        "nommae": nommae,
        "datnascimento": datnasc,
        "telcontato": tel,
        "indsexo": sexo or "M",
    }


def carregar_form_nova_solicitacao(session: requests.Session, csrf: str) -> tuple[str, str]:
    """
    GET tela de inclusão; devolve (authenticity_token do form, csrf atualizado da página).
    """
    path = "/amb/solicitacao/solicitacao_procedimento_servico"
    r = session.get(
        f"{URL_BASE}{path}",
        params={"workMode": "wmInsert", "oldWorkMode": "wmSearch"},
        headers=_headers_ajax(csrf, path),
        timeout=90,
    )
    r.raise_for_status()
    if len(r.text or "") < 200 and "login" in (r.url or "").lower():
        raise RuntimeError("Sessão redirecionou para login ao abrir nova solicitação.")
    csrf2 = _csrf_de_html_ou_fallback(r.text, csrf)
    soup = BeautifulSoup(r.text, "html.parser")
    form = soup.find("form")
    if not form:
        raise RuntimeError("Formulário de nova solicitação não encontrado.")
    tin = form.find("input", {"name": "authenticity_token"})
    if not tin or not tin.get("value"):
        raise RuntimeError("authenticity_token não encontrado no formulário.")
    return str(tin["value"]), csrf2


def _montar_pairs_solicitacao(
    auth_token: str,
    dados: dict[str, Any],
) -> list[tuple[str, str]]:
    """Monta corpo application/x-www-form-urlencoded (lista de pares, ordem estável)."""
    s = dados["solicitacao"]
    itens: list[str] = dados["codigos_procedimento"]
    base_ms = int(time.time_ns() // 1_000_000)
    item_keys = [f"{base_ms}{i:03d}" for i in range(len(itens))]

    pairs: list[tuple[str, str]] = [
        ("oldWorkMode", "wmSearch"),
        ("workMode", "wmInsert"),
        ("utf8", "✓"),
        ("authenticity_token", auth_token),
        ("solicitacao[consulta_especialidade_indicada]", ""),
        ("solicitacao[consulta_avaliacao_procedencia]", ""),
        ("solicitacao[consulta_nivel_prioriadade]", ""),
        ("amb_paciente_id_arquivo", ""),
        ("solicitacao[data_hora_inicio_solicitacao]", s["data_hora_inicio_solicitacao"]),
        ("solicitacao[seg_perfil_id]", s["seg_perfil_id"]),
        ("solicitacao[id]", ""),
        ("solicitacao[data_solicitacao]", s["data_solicitacao"]),
        ("solicitacao[hora_solicitacao]", s["hora_solicitacao"]),
        ("solicitacao[servico_tipo_id]", s["servico_tipo_id"]),
        ("solicitacao[urgencia]", s["urgencia"]),
        ("solicitacao[codigo_municipio_solicitacao]", s["codigo_municipio_solicitacao"]),
        ("solicitacao[codigo_unidade_solicitacao]", s["codigo_unidade_solicitacao"]),
        ("solicitacao[codigo_especialidade]", s["codigo_especialidade"]),
        ("solicitacao[codigo_profissional]", s["codigo_profissional"]),
        ("solicitacao[amb_atendimento_id]", ""),
        ("solicitacao[hos_inh_recepcao_internacao_id]", ""),
        ("solicitacao[codigo_municipio_login]", s["codigo_municipio_login"]),
        ("solicitacao[codigo_unidade_login]", s["codigo_unidade_login"]),
        ("solicitacao[indsexo]", s["indsexo"]),
        ("solicitacao[id_copia]", ""),
        ("solicitacao[habilita_outros_muncipios]", "false"),
        ("solicitacao[numprontuario]", s["numprontuario"]),
        ("solicitacao[nommae]", s["nommae"]),
        ("solicitacao[datnascimento]", s["datnascimento"]),
        ("solicitacao[telcontato]", s["telcontato"]),
        ("solicitacao[resposta_webservice]", ""),
        ("solicitacao[codoperadorlogin]", s["codoperadorlogin"]),
        ("solicitacao[codigo_procedimento]", ""),
        ("solicitacao[codcid]", ""),
        ("solicitacao[quantidade_solicitada]", s["quantidade_solicitada"]),
    ]

    for ik, cod in zip(item_keys, itens):
        cod = re.sub(r"\D", "", cod)
        pairs.extend(
            [
                (f"solicitacao[item_solicitacao_attributes][{ik}][state]", "N"),
                (f"solicitacao[item_solicitacao_attributes][{ik}][id]", ""),
                (
                    f"solicitacao[item_solicitacao_attributes][{ik}][codigo_procedimento]",
                    cod,
                ),
                (f"solicitacao[item_solicitacao_attributes][{ik}][codigo_cid]", ""),
            ]
        )

    pairs.extend(
        [
            ("solicitacao[amb_motivo_agendamento_id]", ""),
            ("solicitacao[codcid_justifica_solicitacao]", ""),
            ("solicitacao[justificativa]", s["justificativa"]),
            ("solicitacao[condicoes_que_justificam]", ""),
            ("solicitacao[resultado_exames_realizados]", ""),
            ("solicitacao[numprontuario_c]", ""),
            ("solicitacao[numprontuarioext_c]", ""),
            ("solicitacao[datainicial_c]", ""),
            ("solicitacao[datafinal_c]", ""),
            ("workMode", "wmInsert"),
            ("oldWorkMode", "wmSearch"),
        ]
    )
    return pairs


def post_nova_solicitacao(
    session: requests.Session,
    csrf: str,
    pairs: list[tuple[str, str]],
) -> requests.Response:
    path = "/amb/solicitacao/solicitacao_procedimento_servico"
    body = urlencode(pairs, encoding="utf-8")
    return session.post(
        f"{URL_BASE}{path}",
        data=body,
        headers={
            **_headers_ajax(csrf, path),
            "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
            "Accept": "text/html, */*; q=0.01",
        },
        timeout=120,
        allow_redirects=True,
    )


def extrair_id_solicitacao_de_resposta(resp: requests.Response) -> str | None:
    text = resp.text or ""
    for pat in (
        r"agendamento_procedimento\?id=(\d+)",
        r"/solicitacao/solicitacao_procedimento_servico/(\d+)(?:[\"'/]|$)",
        r"solicitacao_procedimento_servico/(\d+)/edit",
    ):
        m = re.search(pat, text)
        if m:
            return m.group(1)
    if resp.url:
        m = re.search(r"(?:agendamento_procedimento\?id=|solicitacao_procedimento_servico/)(\d+)", resp.url)
        if m:
            return m.group(1)
    return None


def carregar_pagina_agendamento(session: requests.Session, csrf: str, solicitacao_id: str) -> tuple[str, str]:
    """GET agendamento_procedimento?id=… ; retorna (html, csrf da página)."""
    path = f"/amb/solicitacao/agendamento_procedimento?id={solicitacao_id}"
    r = session.get(
        f"{URL_BASE}{path}",
        headers=_headers_ajax(csrf, path),
        timeout=90,
    )
    r.raise_for_status()
    return r.text, _csrf_de_html_ou_fallback(r.text, csrf)


def extrair_mapa_fila_por_procedimento(html: str, codigos: list[str]) -> dict[str, str]:
    """
    O SIS embute em `table#table_procedimento_solicitado` o atributo data-procedimentos
    (JSON). Cada item tem `id` (linha da solicitação) e `codigo_procedimento`; esse `id`
    é o mesmo usado no POST fila_espera_procedimento[id] (não vem como input hidden no HTML).
    """
    cod_norm = [re.sub(r"\D", "", c) for c in codigos if re.sub(r"\D", "", c)]
    soup = BeautifulSoup(html, "html.parser")
    tab = soup.find("table", id="table_procedimento_solicitado")
    if tab and tab.get("data-procedimentos"):
        raw = str(tab["data-procedimentos"])
        try:
            arr = json.loads(raw)
        except (json.JSONDecodeError, TypeError):
            arr = []
        por_codigo: dict[str, str] = {}
        for row in arr:
            if not isinstance(row, dict):
                continue
            cc = re.sub(r"\D", "", str(row.get("codigo_procedimento") or ""))
            rid = row.get("id")
            if cc and rid is not None and str(rid).strip():
                por_codigo[cc] = str(rid).strip()
        return {c: por_codigo[c] for c in cod_norm if c in por_codigo}

    # Fallback legado (HTML com inputs, se existir)
    found: dict[str, str] = {}

    def _nome_eh_id_fila(name: str) -> bool:
        n = (name or "").strip()
        if n == "fila_espera_procedimento[id]":
            return True
        return bool(
            re.search(r"fila[_\w]*espera[_\w]*procedimento", n, re.I)
            and re.search(r"\[id\]", n)
            and "motivo" not in n.lower()
            and "prioridade" not in n.lower()
            and "data" not in n.lower()
            and "observacao" not in n.lower()
        )

    for tr in soup.find_all("tr"):
        hid = None
        for inp in tr.find_all("input"):
            if _nome_eh_id_fila(inp.get("name") or ""):
                hid = inp
                break
        if not hid or not hid.get("value"):
            continue
        fid = str(hid["value"]).strip()
        row_txt = tr.get_text(" ", strip=True)
        digits_only = re.sub(r"\D", "", row_txt)
        for c in cod_norm:
            if c and c in digits_only:
                found[c] = fid

    if len(found) < len(cod_norm):
        ordered: list[str] = []
        seen: set[str] = set()
        for m in re.finditer(
            r'<input[^>]+name=(["\'])fila_espera_procedimento\[id\]\1[^>]*value=\1(\d+)\1',
            html,
            re.I,
        ):
            v = m.group(2).strip()
            if v and v not in seen:
                seen.add(v)
                ordered.append(v)
        if len(ordered) >= len(cod_norm):
            for c, fid in zip(cod_norm, ordered):
                found.setdefault(c, fid)

    return {c: found[c] for c in cod_norm if c in found}


def post_fila_espera(
    session: requests.Session,
    csrf: str,
    solicitacao_id: str,
    fila_item_id: str,
    observacao: str,
    data_envio: str,
) -> requests.Response:
    path = "/amb/solicitacao/agendamento_procedimento/fila_espera_procedimento"
    referer = f"/amb/solicitacao/agendamento_procedimento?id={solicitacao_id}"
    pairs = [
        ("fila_espera_procedimento[id]", fila_item_id),
        ("fila_espera_procedimento[observacao]", observacao),
        ("fila_espera_procedimento[motivo_priorizacao_id]", MOTIVO_PRIORIZACAO_ID),
        (
            "fila_espera_procedimento[ram_servico_fila_nivel_prioridade_id]",
            RAM_SERVICO_FILA_NIVEL_PRIORIDADE_ID,
        ),
        ("fila_espera_procedimento[data_envio]", data_envio),
        ("fila_espera_procedimento[data_min_agendamento]", ""),
    ]
    body = urlencode(pairs, encoding="utf-8")
    return session.post(
        f"{URL_BASE}{path}",
        data=body,
        headers={
            **_headers_ajax(csrf, referer),
            "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
            "Accept": "*/*",
        },
        timeout=90,
    )


def tentar_excluir_solicitacao_apos_falha_fila(
    session: requests.Session,
    csrf_ref: list[str],
    solicitacao_id: str,
) -> tuple[bool, str]:
    """
    Tenta excluir solicitação recém-criada (POST _method=delete + authenticity_token).
    Usado quando nenhum POST de fila teve sucesso.
    """
    if not TENTAR_EXCLUIR_SOLICITACAO_SE_FILA_FALHAR_TUDO:
        return False, "exclusão automática desligada na configuração"

    ref_lista = "/amb/solicitacao/solicitacao_procedimento_servico"
    ref_item = f"/amb/solicitacao/solicitacao_procedimento_servico/{solicitacao_id}"

    for path_get, q in (
        (f"{ref_item}/edit", {"workMode": "wmEdit", "oldWorkMode": "wmBrowse"}),
        (ref_item, {"workMode": "wmBrowse", "oldWorkMode": "wmSearch"}),
    ):
        r = session.get(
            f"{URL_BASE}{path_get}",
            params=q,
            headers=_headers_ajax(csrf_ref[0], ref_lista),
            timeout=90,
        )
        if r.status_code >= 400:
            continue
        csrf_ref[0] = _csrf_de_html_ou_fallback(r.text, csrf_ref[0])
        soup = BeautifulSoup(r.text, "html.parser")
        auth = None
        for inp in soup.find_all("input", {"name": "authenticity_token"}):
            v = inp.get("value")
            if v:
                auth = str(v).strip()
                break
        if not auth:
            continue

        pairs = [
            ("_method", "delete"),
            ("authenticity_token", auth),
        ]
        rd = session.post(
            f"{URL_BASE}{ref_item}",
            data=urlencode(pairs),
            headers={
                **_headers_ajax(csrf_ref[0], ref_item),
                "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
                "Accept": "text/html, */*; q=0.01",
            },
            timeout=90,
            allow_redirects=True,
        )
        if rd.text:
            csrf_ref[0] = _csrf_de_html_ou_fallback(rd.text, csrf_ref[0])
        url_l = (rd.url or "").lower()
        if "login" in url_l:
            return False, "sessão expirou ao excluir"
        if rd.status_code < 400:
            return True, ""
        return False, f"exclusão HTTP {rd.status_code}"

    return False, "authenticity_token para exclusão não encontrado"


def _garantir_colunas(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    if out.shape[1] < MIN_COLUNAS:
        faltam = MIN_COLUNAS - out.shape[1]
        for i in range(faltam):
            out[f"_pad_{i}"] = None
        cname = out.columns[COL_RESULTADO]
        if str(cname).startswith("_pad_"):
            out.rename(columns={cname: "Resultado"}, inplace=True)
    return out


def _listar_arquivos_ods() -> list[Path]:
    """Lista .ods a processar (ordenado por nome)."""
    if CAMINHO_PLANILHA_EXATO.strip():
        p = Path(CAMINHO_PLANILHA_EXATO.strip())
        if not p.is_file():
            raise FileNotFoundError(p)
        return [p]
    pasta = Path(PASTA_PLANILHAS)
    if not pasta.is_dir():
        raise NotADirectoryError(str(pasta))
    candidatos = sorted(
        p
        for p in pasta.glob("*.ods")
        if p.is_file() and not p.name.upper().startswith("OK ")
    )
    if not candidatos:
        raise FileNotFoundError(f"Nenhum .ods em {pasta} (exceto prefixo OK )")
    return candidatos


def _carregar_ods(path: Path) -> tuple[pd.DataFrame, str, dict[str, pd.DataFrame]]:
    xl = pd.ExcelFile(path, engine="odf")
    nomes = xl.sheet_names
    if not nomes:
        raise RuntimeError("ODS sem abas.")
    if NOME_ABA is None:
        nome_aba = nomes[0]
    elif isinstance(NOME_ABA, int):
        nome_aba = nomes[NOME_ABA]
    else:
        nome_aba = str(NOME_ABA)
        if nome_aba not in nomes:
            raise RuntimeError(f"Aba não encontrada: {nome_aba!r}. Abas: {nomes}")
    todas = {n: xl.parse(n, header=0) for n in nomes}
    return todas[nome_aba], nome_aba, todas


def _salvar_ods(path: Path, nome_aba: str, todas: dict[str, pd.DataFrame]) -> None:
    with pd.ExcelWriter(path, engine="odf", mode="w") as writer:
        for nome, dframe in todas.items():
            dframe.to_excel(writer, sheet_name=nome, index=False)


def _parse_data_br(s: Any) -> str:
    if s is None or (isinstance(s, float) and pd.isna(s)):
        raise ValueError("Data vazia.")
    t = str(s).strip()
    if not t:
        raise ValueError("Data vazia.")
    for fmt in ("%d/%m/%Y", "%Y-%m-%d"):
        try:
            return datetime.strptime(t[:10] if fmt == "%Y-%m-%d" else t, fmt).strftime("%d/%m/%Y")
        except ValueError:
            continue
    raise ValueError(f"Data inválida (use dd/mm/yyyy): {t!r}")


def _parse_procedimentos(s: Any) -> list[str]:
    if s is None or (isinstance(s, float) and pd.isna(s)):
        return []
    raw = str(s).strip()
    partes = re.split(r"[,;\n]+", raw)
    out = [re.sub(r"\D", "", p) for p in partes if str(p).strip()]
    return [p for p in out if p]


def _cel_str(row: pd.Series, idx: int) -> str:
    if idx >= len(row):
        return ""
    v = row.iloc[idx]
    if v is None or (isinstance(v, float) and pd.isna(v)):
        return ""
    if isinstance(v, float) and v == int(v):
        return str(int(v))
    return str(v).strip()


def _linha_prontuario_valido(row: pd.Series) -> bool:
    """Prontuário numérico != 0; vazio, NaN, texto não numérico ou zero = inválido."""
    raw = _cel_str(row, COL_PRONTUARIO).strip()
    if not raw:
        return False
    low = raw.lower()
    if low in ("nan", "none", "-", "—", "n/a"):
        return False
    try:
        n = int(float(raw.replace(",", ".").replace(" ", "")))
    except ValueError:
        return False
    return n != 0


def _faixa_linhas_por_prontuario(df: pd.DataFrame) -> tuple[int, int]:
    """
    Ignora linhas iniciais sem prontuário válido.
    Considera só o bloco contíguo desde o primeiro prontuário válido até a última linha
    antes da primeira com prontuário vazio/nulo/zero (lixo comum em export de planilha).

    Retorna (início, fim) inclusive em índice iloc; (0, -1) se não houver linha válida.
    """
    n = len(df)
    start = 0
    while start < n and not _linha_prontuario_valido(df.iloc[start]):
        start += 1
    if start >= n:
        return (0, -1)
    end = start
    for i in range(start, n):
        if not _linha_prontuario_valido(df.iloc[i]):
            break
        end = i
    return (start, end)


def processar_linha(
    session: requests.Session,
    csrf_ref: list[str],
    sessao_ctx: dict[str, str],
    prontuario: str,
    data_solic: str,
    cod_unidade: str,
    procedimentos: list[str],
) -> tuple[bool, str, str]:
    """
    Retorna (ok, mensagem, novo_csrf).
    csrf_ref: lista de um elemento para atualizar CSRF mutável entre chamadas.
    sessao_ctx: preenchido no login com codoperadorlogin e seg_perfil_id (HTML /desktop).
    """
    csrf = csrf_ref[0]
    pid = buscar_paciente_id(session, csrf, prontuario)
    if not pid:
        return False, f"Paciente não encontrado (prontuário {prontuario}).", csrf

    amb = carregar_dados_paciente_edicao(session, csrf, pid)
    pac = _mapear_paciente_para_solicitacao(amb)
    if not pac["nommae"] or not pac["datnascimento"]:
        return False, "Cadastro incompleto (nome da mãe ou data nascimento vazios).", csrf

    hora_sol = HORA_SOLICITACAO_FIXA
    data_hora_inicio = f"{data_solic} {hora_sol}"

    auth, csrf = carregar_form_nova_solicitacao(session, csrf)
    csrf_ref[0] = csrf

    sol = {
        "data_hora_inicio_solicitacao": data_hora_inicio,
        "seg_perfil_id": sessao_ctx["seg_perfil_id"],
        "data_solicitacao": data_solic,
        "hora_solicitacao": hora_sol,
        "servico_tipo_id": SERVICO_TIPO_ID,
        "urgencia": URGENCIA,
        "codigo_municipio_solicitacao": COD_MUNICIPIO,
        "codigo_unidade_solicitacao": str(cod_unidade).strip(),
        "codigo_especialidade": COD_ESPECIALIDADE,
        "codigo_profissional": COD_PROFISSIONAL,
        "codigo_municipio_login": COD_MUNICIPIO,
        "codigo_unidade_login": str(cod_unidade).strip(),
        "indsexo": pac["indsexo"],
        "numprontuario": str(prontuario).strip(),
        "nommae": pac["nommae"],
        "datnascimento": pac["datnascimento"],
        "telcontato": pac["telcontato"] or " ",
        "codoperadorlogin": str(sessao_ctx["codoperadorlogin"]).strip(),
        "quantidade_solicitada": str(QUANTIDADE_SOLICITADA),
        "justificativa": JUSTIFICATIVA_OBSERVACAO_FIXA.strip() or " ",
    }

    pairs = _montar_pairs_solicitacao(
        auth,
        {"solicitacao": sol, "codigos_procedimento": procedimentos},
    )
    resp = post_nova_solicitacao(session, csrf, pairs)
    if resp.text and "csrf-token" in resp.text:
        try:
            csrf_ref[0] = _extrair_csrf(resp.text)
        except RuntimeError:
            pass

    if resp.status_code >= 400:
        return False, f"HTTP {resp.status_code} ao salvar solicitação.", csrf_ref[0]

    sid = extrair_id_solicitacao_de_resposta(resp)
    if not sid:
        snippet = (resp.text or "")[:800]
        return (
            False,
            "Não foi possível obter o ID da solicitação na resposta. "
            f"Trecho: {snippet!r}",
            csrf_ref[0],
        )

    html_ag, csrf_ag = carregar_pagina_agendamento(session, csrf_ref[0], sid)
    csrf_ref[0] = csrf_ag

    mapa_fila = extrair_mapa_fila_por_procedimento(html_ag, procedimentos)
    obs_fila = JUSTIFICATIVA_OBSERVACAO_FIXA.strip() or "SOLICITAÇÃO IMPORTADA"
    erros_fila: list[str] = []
    sucesso_fila = 0

    for cod in [re.sub(r"\D", "", c) for c in procedimentos]:
        fid = mapa_fila.get(cod)
        if not fid:
            erros_fila.append(f"sem id de fila para {cod}")
            continue
        r_f = post_fila_espera(session, csrf_ref[0], sid, fid, obs_fila, data_solic)
        if r_f.status_code < 400:
            sucesso_fila += 1
        else:
            erros_fila.append(f"fila {cod}: HTTP {r_f.status_code}")
        if r_f.text and "csrf-token" in r_f.text:
            try:
                csrf_ref[0] = _extrair_csrf(r_f.text)
            except RuntimeError:
                pass

    if erros_fila:
        msg_base = f"Solicitação {sid}: " + "; ".join(erros_fila)
        if sucesso_fila == 0:
            ok_del, motivo_del = tentar_excluir_solicitacao_apos_falha_fila(
                session, csrf_ref, sid
            )
            if ok_del:
                msg_base += " Solicitação excluída automaticamente (nada enviado à fila)."
            else:
                msg_base += (
                    f" Não foi possível excluir automaticamente ({motivo_del}). "
                    f"Cancele manualmente a solicitação {sid} no SIS."
                )
        else:
            msg_base += (
                f" Parcial: {sucesso_fila} procedimento(s) na fila; corrija o restante "
                f"na solicitação {sid} no sistema."
            )
        return False, msg_base, csrf_ref[0]

    return True, f"OK — solicitação {sid} e fila.", csrf_ref[0]


def processar_um_arquivo_ods(
    session: requests.Session,
    path_ods: Path,
    csrf_box: list[str],
    sessao_ctx: dict[str, str],
) -> None:
    """Processa linhas de um ODS; grava resultados e renomeia com OK se tudo der certo."""
    print(f"\n--- Arquivo: {path_ods.name} ---")
    df, nome_aba, todas = _carregar_ods(path_ods)
    df = _garantir_colunas(df)
    c_res = df.columns[COL_RESULTADO]
    df[c_res] = df[c_res].astype(object)
    todas[nome_aba] = df

    ini, fim = _faixa_linhas_por_prontuario(df)
    if fim < ini:
        print("  Nenhuma linha com prontuário válido (numérico e ≠ 0); nada a processar.")
        return

    indices = list(range(ini, fim + 1))
    if LINHAS_MAX is not None:
        indices = indices[: max(0, LINHAS_MAX)]
    if not indices:
        print("  Nenhuma linha a processar (faixa vazia ou LINHAS_MAX=0).")
        return

    n_linhas = len(indices)
    ult = indices[-1]
    print(
        f"  Faixa por prontuário: linhas da planilha {ini + 2}–{ult + 2} "
        f"({n_linhas} linha(s) com prontuário válido"
        + (f", limite LINHAS_MAX={LINHAS_MAX}" if LINHAS_MAX is not None else "")
        + ")."
    )
    falhas = 0
    linhas_com_dados = 0

    for i in indices:
        row = df.iloc[i]
        pront = _cel_str(row, COL_PRONTUARIO)
        linhas_com_dados += 1
        msg = ""
        try:
            data_sol = _parse_data_br(row.iloc[COL_DATA_SOLIC])
            unidade = _cel_str(row, COL_UNIDADE)
            procs = _parse_procedimentos(row.iloc[COL_PROCEDIMENTOS])
            if not unidade or not procs:
                msg = "Unidade ou procedimentos vazios."
                falhas += 1
            else:
                ok, msg, _ = processar_linha(
                    session, csrf_box, sessao_ctx, pront, data_sol, unidade, procs
                )
                if not ok:
                    falhas += 1
            print(f"  Linha {i + 2}: prontuário {pront} -> {msg}")
        except Exception as e:
            falhas += 1
            msg = str(e)
            print(f"  Linha {i + 2}: ERRO {e}")

        df.iat[i, COL_RESULTADO] = msg
        todas[nome_aba] = df
        _salvar_ods(path_ods, nome_aba, todas)
        time.sleep(DELAY_ENTRE_LINHAS)

    if falhas == 0 and linhas_com_dados > 0:
        novo = path_ods.parent / f"OK {path_ods.name}"
        path_ods.rename(novo)
        print(f"  OK: renomeado para {novo.name}")
    else:
        msg_extra = "" if linhas_com_dados else " (nenhuma linha com prontuário)"
        print(
            f"  Fim: {falhas} falha(s){msg_extra}. "
            "ODS atualizado neste arquivo; sem renomeação OK."
        )


def main() -> None:
    print("wsSolicitaServico — importação de demanda")
    print(f"URL_BASE: {URL_BASE}")
    print(f"Justificativa/fila fixa: {JUSTIFICATIVA_OBSERVACAO_FIXA!r}")

    arquivos = _listar_arquivos_ods()
    print(f"Planilhas a processar ({len(arquivos)}): {', '.join(p.name for p in arquivos)}")

    if not SENHA_SIS:
        raise SystemExit("Configure SENHA_SIS no script.")

    session = requests.Session()
    sessao_ctx: dict[str, str] = {}
    csrf_login = fazer_login(session, USUARIO_SIS, SENHA_SIS, sessao_ctx)
    csrf_box: list[str] = [csrf_login]

    for path_ods in arquivos:
        processar_um_arquivo_ods(session, path_ods, csrf_box, sessao_ctx)

    print("\nTodos os arquivos da fila foram processados.")


if __name__ == "__main__":
    main()
